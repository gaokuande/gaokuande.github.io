# Django Job Portal Website 
![django_jobportal](https://user-images.githubusercontent.com/39632170/69029517-62602500-09ff-11ea-8ef3-13356607e338.png)
