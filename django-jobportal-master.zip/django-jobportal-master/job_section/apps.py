from django.apps import AppConfig


class JobSectionConfig(AppConfig):
    name = 'job_section'
